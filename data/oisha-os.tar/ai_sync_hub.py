import json
import logging
import sqlite3
from datetime import datetime

logger = logging.getLogger(__name__)

class AISyncHub:
    """OpenAI, Claude, Gemini va Manus suhbatlarini birlashtirish moduli."""

    @staticmethod
    def ingest_openai_export(json_file_path, user_id):
        """ChatGPT dan eksport qilingan JSON ma'lumotlarini Oisha xotirasiga o'tkazish."""
        try:
            with open(json_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            conn = sqlite3.connect("bot_memory.db")
            cursor = conn.cursor()
            
            count = 0
            for conversation in data:
                title = conversation.get('title', 'No Title')
                mapping = conversation.get('mapping', {})
                for node_id in mapping:
                    node = mapping[node_id]
                    message = node.get('message')
                    if message and message.get('content'):
                        content_parts = message['content'].get('parts', [])
                        text = " ".join([str(p) for p in content_parts if isinstance(p, str)])
                        role = message.get('author', {}).get('role', 'unknown')
                        
                        if text.strip():
                            # Oisha xotirasiga 'External Knowledge' sifatida saqlaymiz
                            fact = f"ChatGPT ({title}) - {role}: {text[:500]}..."
                            cursor.execute("INSERT INTO learned_facts (user_id, fact) VALUES (?, ?)", (user_id, fact))
                            count += 1
            
            conn.commit()
            conn.close()
            logger.info(f"[SYNC] Ingested {count} messages from OpenAI export for user {user_id}")
            return f"{count} ta xabar muvaffaqiyatli sinxronizatsiya qilindi."
        except Exception as e:
            logger.error(f"[OPENAI SYNC ERROR] {e}")
            return f"Xatolik yuz berdi: {e}"

    @staticmethod
    def sync_new_thread(platform, thread_id, messages, user_id):
        """Yangi suhbatlarni real vaqtda sinxronizatsiya qilish (API orqali)."""
        # Bu yerda API orqali kelgan xabarlarni bazaga saqlash logikasi
        try:
            conn = sqlite3.connect("bot_memory.db")
            cursor = conn.cursor()
            for msg in messages:
                fact = f"{platform} (Live) - {msg['role']}: {msg['content']}"
                cursor.execute("INSERT INTO learned_facts (user_id, fact) VALUES (?, ?)", (user_id, fact))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"[{platform} LIVE SYNC ERROR] {e}")
            return False
