
import logging
from typing import Optional, Dict, Any
from settings import settings, logger
from agent_core import AgentManager
from agents.sales_agent import SalesAgent
from agents.pm_agent import PMAgent
from agents.researcher_agent import ResearcherAgent
from agents.support_agent import SupportAgent
from agent_orchestrator import AgentOrchestrator
from services.crm_service import CRMService
from services.google_service import GoogleService
from services.enterprise_reporter import EnterpriseReporter
from agent_tools import AgentToolExecutor
from database import Database
import config

logger = logging.getLogger(__name__)

class MessageController:
    """Xabarlarni qayta ishlash mantiqini boshqaruvchi controller."""
    
    def __init__(self, api_keys: Dict[str, str], db: Optional[Database] = None):
        self.api_keys = api_keys
        self.db = db or Database()
        self.agent_manager = AgentManager(api_keys)
        self.orchestrator = AgentOrchestrator(self.agent_manager)
        self.crm = CRMService()
        self.google = GoogleService()
        self.enterprise_reporter = EnterpriseReporter(db=self.db, crm=self.crm)
        
        # Executor initialization (bot_app to be set later)
        self.executor = AgentToolExecutor(
            db=self.db,
            gcontacts=self.google.contacts,
            gcalendar=self.google.calendar,
            gsheet=self.google.sheets,
            amocrm=self.crm.amocrm, # Corrected parameter name
            bot_app=None, # Will be set via set_bot_app
            config=config
        )
        
        # Agentlarni ro'yxatdan o'tkazish
        # Barcha agentlar uchun Oisha (Biznes ToV) asosiy ko'rsatma bo'ladi
        system_instruction = getattr(settings, 'SYSTEM_INSTRUCTION', "Siz JonBranding yordamchisisiz.")
        
        self.agent_manager.register_agent(SalesAgent("sales", system_instruction, api_keys, self.executor, self.db))
        
        # PM va Researcher uchun faqat vazifa qo'shamiz, lekin Oisha obrazini saqlaymiz
        pm_prompt = system_instruction + "\n\nSiz ayniqsa loyihalarni rejalashtirish va ularni boshqarish bo'yicha masuliyatlisiz."
        self.agent_manager.register_agent(PMAgent("strategist", pm_prompt, api_keys, self.executor, self.db))
        
        research_prompt = system_instruction + "\n\nSiz ayniqsa bozor tahlili, OSINT yoki chuqur tadqiqotlar uchun masuliyatlisiz."
        self.agent_manager.register_agent(ResearcherAgent("researcher", research_prompt, api_keys, self.executor, self.db))
        
        support_prompt = system_instruction + "\n\nSiz ayniqsa tezkor yordam va texnik savollar uchun masuliyatlisiz."
        self.agent_manager.register_agent(SupportAgent("support", support_prompt, api_keys, self.executor, self.db))

    def set_bot_app(self, bot_app):
        """Telegram application built bo'lgandan so'ng executorga uzatish."""
        self.executor.bot_app = bot_app
        logger.info("[AGENT CONTROLLER] Bot application connected to executor.")

    async def get_response(self, user_id: int, user_name: str, message: str, context: Optional[Dict[str, Any]] = None) -> str:
        """Asosiy javob qaytarish mantiqi."""
        context = context or {}
        
        # 1. CRM dan user haqida ma'lumot olish (agar tel bo'lsa)
        user_info = self.db.get_user_info(user_id)
        crm_status = "Yangi mijoz"
        if user_info and user_info.get("phone"):
            crm_status = await self.crm.get_user_context(user_info["phone"])
        
        context["crm_status"] = crm_status

        # 2. Intentni aniqlash (LLM routing)
        agent_id = await self.orchestrator.determine_intent(message)
        
        # 3. Agent orqali javob olish (kontekst bilan birga)
        return await self.orchestrator.get_agent_response(agent_id, user_id, message, context=context)
