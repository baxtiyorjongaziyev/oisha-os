Set WshShell = CreateObject("WScript.Shell")
WshShell.Run chr(34) & "c:\Users\baxti\.gemini\antigravity\playground\oisha-os\start_oisha.bat" & Chr(34), 0
Set WshShell = Nothing
