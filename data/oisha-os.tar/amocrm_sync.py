import os
import time
import json
import logging
import requests  # type: ignore
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)

class AmoCRMSync:
    def __init__(self, subdomain, client_id, client_secret, redirect_url, token_file="amocrm_token.json"):
        self.subdomain = subdomain
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_url = redirect_url
        self.token_file = token_file
        self.base_url = f"https://{subdomain}.amocrm.ru"
        self.access_token: Optional[str] = None
        self.token_data: Dict[str, Any] = {}
        
        # Security: Masked log for safety
        logger.info(f"[AMOCRM INIT] Subdomain: {subdomain}")

    def _load_token(self):
        """Tokenni fayldan o'qish."""
        if os.path.exists(self.token_file):
            try:
                with open(self.token_file, "r") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        self.token_data = data
                        self.access_token = str(data.get("access_token", "")) if data.get("access_token") else None
            except Exception as e:
                logger.error(f"[AMOCRM] Token yuklashda xato: {e}")

    def _save_token(self, token_data):
        """Tokenni faylga saqlash."""
        try:
            with open(self.token_file, "w") as f:
                json.dump(token_data, f)
            self.token_data = token_data
            self.access_token = token_data.get("access_token")
        except Exception as e:
            logger.error(f"[AMOCRM] Token saqlashda xato: {e}")

    def refresh_token(self):
        """Refresh token yordamida yangi access token olish."""
        if not self.token_data.get("refresh_token"):
            logger.error("[AMOCRM] Refresh token topilmadi.")
            return False

        url = f"{self.base_url}/oauth2/access_token"
        data = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "grant_type": "refresh_token",
            "refresh_token": self.token_data.get("refresh_token", ""),
            "redirect_uri": self.redirect_url,
        }
        
        try:
            response = requests.post(url, data=data)
            if response.status_code == 200:
                self._save_token(response.json())
                logger.info("[AMOCRM OK] Token yangilandi.")
                return True
            else:
                print(f"!!! AMOCRM REFRESH FAILED: {response.status_code} - {response.text}")
                logger.error(f"[AMOCRM ERROR] Token yangilashda xato: {response.text}")
                return False
        except Exception as e:
            logger.error(f"[AMOCRM ERROR] Request yuborishda xato: {e}")
            return False

    def authorize_initial(self, auth_code):
        """Birinchi marta kod yordamida token olish."""
        url = f"{self.base_url}/oauth2/access_token"
        data = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "grant_type": "authorization_code",
            "code": auth_code,
            "redirect_uri": self.redirect_url,
        }
        
        try:
            response = requests.post(url, data=data)
            if response.status_code == 200:
                self._save_token(response.json())
                logger.info("[AMOCRM OK] Dastlabki avtorizatsiya muvaffaqiyatli.")
                return True
            else:
                logger.error(f"[AMOCRM ERROR] Avtorizatsiyada xato: {response.text}")
                return False
        except Exception as e:
            logger.error(f"[AMOCRM ERROR] Request yuborishda xato: {e}")
            return False

    def _get_headers(self):
        token = str(self.access_token or "")
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

    def create_lead(self, name, phone, price=0, note=""):
        """Yangi bitim (Lead) yaratish."""
        if not self.access_token:
            self._load_token()

        url = f"{self.base_url}/api/v4/leads/complex"
        
        # Murakkab so'rov: Bitim + Kontakt yaratish
        lead_entry = {
            "name": f"Loyiha: {name}",
            "price": price,
            "_embedded": {
                "contacts": [
                    {
                        "first_name": name,
                        "custom_fields_values": [
                            {
                                "field_code": "PHONE",
                                "values": [
                                    {"value": phone, "enum_code": "MOB"}
                                ]
                            }
                        ]
                    }
                ]
            }
        }
        
        # Tagging for missing phone
        if phone == "Raqam yo'q" or not phone:
            lead_entry["_embedded"]["tags"] = [{"name": "PHONE_REQUIRED"}]
            
        data = [lead_entry]

        try:
            response = requests.post(url, headers=self._get_headers(), json=data)
            if response.status_code == 401:
                if self.refresh_token():
                    response = requests.post(url, headers=self._get_headers(), json=data)
            
            if response.status_code in [200, 201]:
                logger.info(f"[AMOCRM OK] Bitim yaratildi: {name}")
                return True
            else:
                logger.error(f"[AMOCRM ERROR] Bitim yaratishda xato: {response.text}")
                return False
        except Exception as e:
            logger.error(f"[AMOCRM ERROR] Request yuborishda xato: {e}")
            return False

    def get_lead_by_phone(self, phone: str) -> Optional[Dict[str, Any]]:
        """Telefon raqami orqali bitimni qidirish."""
        if not self.access_token:
            self._load_token()
        
        url = f"{self.base_url}/api/v4/contacts"
        params = {"query": phone}
        try:
            response = requests.get(url, headers=self._get_headers(), params=params)
            if response.status_code == 200:
                data = response.json()
                if not data: return None
                contacts = data.get("_embedded", {}).get("contacts", [])
                if contacts:
                    contact = contacts[0]
                    leads = contact.get("_embedded", {}).get("leads", [])
                    if leads:
                        lead_id = leads[0].get("id")
                        lead_url = f"{self.base_url}/api/v4/leads/{lead_id}"
                        lead_resp = requests.get(lead_url, headers=self._get_headers())
                        if lead_resp.status_code == 200:
                            return lead_resp.json()
            return None
        except Exception as e:
            logger.error(f"[AMOCRM FIND ERROR] {e}")
            return None

    def get_lead_status_text(self, lead: Dict[str, Any]) -> str:
        """Bitim holatini matn ko'rinishida qaytarish."""
        if not lead: return "Yangi mijoz"
        price = lead.get("price", 0)
        status_id = lead.get("status_id")
        return f"Mavjud mijoz. Bitim narxi: {price}. Status ID: {status_id}"

    async def get_user_context(self, phone: str) -> str:
        """User uchun kontekstni (lead statusini) olish."""
        lead = self.get_lead_by_phone(phone)
        return self.get_lead_by_phone(phone) if lead else "Yangi mijoz"

    async def get_leads(self, status_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """Bitimlarni (Leads) olish. Basic plan uchun sodda so'rovlar."""
        if not self.access_token:
            self._load_token()
        
        url = f"{self.base_url}/api/v4/leads"
        params = {"limit": 50}
        if status_id:
            params["filter[status]"] = status_id
            
        try:
            response = requests.get(url, headers=self._get_headers(), params=params)
            if response.status_code == 401:
                if self.refresh_token():
                    response = requests.get(url, headers=self._get_headers(), params=params)
            
            if response.status_code == 200:
                data = response.json()
                return data.get("_embedded", {}).get("leads", [])
            return []
        except Exception as e:
            logger.error(f"[AMOCRM GET LEADS ERROR] {e}")
            return []

    async def create_task(self, element_id: int, text: str, complete_till: int):
        """Lid uchun vazifa yaratish."""
        if not self.access_token:
            self._load_token()
            
        url = f"{self.base_url}/api/v4/tasks"
        data = [
            {
                "task_type_id": 1, # Call or generic task
                "text": text,
                "complete_till": complete_till,
                "entity_id": element_id,
                "entity_type": "leads"
            }
        ]
        
        try:
            response = requests.post(url, headers=self._get_headers(), json=data)
            if response.status_code == 201:
                logger.info(f"[AMOCRM OK] Vazifa yaratildi: {element_id}")
                return True
            return False
        except Exception as e:
            logger.error(f"[AMOCRM TASK ERROR] {e}")
            return False

    async def get_tasks(self, is_completed: bool = False) -> List[Dict[str, Any]]:
        """AmoCRM dan vazifalarni olish."""
        if not self.access_token:
            self._load_token()
            
        url = f"{self.base_url}/api/v4/tasks"
        params = {"filter[is_completed]": 1 if is_completed else 0}
        
        try:
            response = requests.get(url, headers=self._get_headers(), params=params)
            if response.status_code == 200:
                data = response.json()
                return data.get("_embedded", {}).get("tasks", [])
            return []
        except Exception as e:
            logger.error(f"[AMOCRM GET TASKS ERROR] {e}")
            return []

    async def get_leads_detailed(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Bitimlarni batafsil ma'lumotlari bilan olish. Basic plan uchun order olib tashlandi."""
        if not self.access_token:
            self._load_token()
            
        url = f"{self.base_url}/api/v4/leads"
        # 'order' parametri Basic planda 402/501 berishi mumkin
        params = {"limit": min(limit, 50)} 
        
        try:
            response = requests.get(url, headers=self._get_headers(), params=params)
            if response.status_code == 401:
                if self.refresh_token():
                    response = requests.get(url, headers=self._get_headers(), params=params)

            if response.status_code == 200:
                data = response.json()
                return data.get("_embedded", {}).get("leads", [])
            elif response.status_code == 402:
                logger.error("[AMOCRM 402] Payment Required. Basic tarifda limitlar bor.")
            return []
        except Exception as e:
            logger.error(f"[AMOCRM DETAILED LEADS ERROR] {e}")
            return []

    async def update_lead_status(self, lead_id: int, status_id: int, pipeline_id: int = None):
        """Bitim statusini (va ixtiyoriy ravishda pipelineni) yangilash."""
        url = f"{self.base_url}/api/v4/leads/{lead_id}"
        data = {"status_id": status_id}
        if pipeline_id:
            data["pipeline_id"] = pipeline_id
        
        try:
            response = requests.patch(url, headers=self._get_headers(), json=data)
            if response.status_code == 200:
                logger.info(f"[AMOCRM OK] Status yangilandi: {lead_id} -> {status_id} (P:{pipeline_id})")
                return True
            return False
        except Exception as e:
            logger.error(f"[AMOCRM UPDATE ERROR] {e}")
            return False

    async def update_lead_custom_fields(self, lead_id: int, fields_dict: dict):
        """Custom fieldlarni yangilash. fields_dict: {field_id: enum_id_yoki_text}"""
        url = f"{self.base_url}/api/v4/leads/{lead_id}"
        
        custom_fields = []
        for f_id, f_val in fields_dict.items():
            if isinstance(f_val, int):
                custom_fields.append({"field_id": int(f_id), "values": [{"enum_id": f_val}]})
            else:
                custom_fields.append({"field_id": int(f_id), "values": [{"value": str(f_val)}]})

        data = {"custom_fields_values": custom_fields}
        try:
            response = requests.patch(url, headers=self._get_headers(), json=data)
            if response.status_code == 200:
                logger.info(f"[AMOCRM OK] Custom fields yangilandi: {lead_id}")
                return True
            return False
        except Exception as e:
            logger.error(f"[AMOCRM FIELDS ERROR] {e}")
            return False

    async def add_lead_tag(self, lead_id: int, tag_name: str):
        """Lidga teg qo'shish."""
        url = f"{self.base_url}/api/v4/leads/{lead_id}"
        data = {"_embedded": {"tags": [{"name": tag_name}]}}
        
        try:
            response = requests.patch(url, headers=self._get_headers(), json=data)
            if response.status_code == 200:
                logger.info(f"[AMOCRM OK] Teg qo'shildi: {lead_id} -> {tag_name}")
                return True
            return False
        except Exception as e:
            logger.error(f"[AMOCRM TAG ERROR] {e}")
            return False

    def get_all_leads(self, limit: int = 250) -> List[Dict[str, Any]]:
        """Barcha lidlarni olish (re-engagement uchun)."""
        url = f"{self.base_url}/api/v4/leads"
        params = {"limit": limit, "order[updated_at]": "desc"}
        
        try:
            response = requests.get(url, headers=self._get_headers(), params=params)
            if response.status_code == 200:
                return response.json().get("_embedded", {}).get("leads", [])
            return []
        except Exception as e:
            logger.error(f"[AMOCRM GET ALL LEADS ERROR] {e}")
            return []

    def get_lead_phone(self, lead_id: int) -> Optional[str]:
        """Lidga biriktirilgan birinchi telefon raqamini olish."""
        url = f"{self.base_url}/api/v4/leads/{lead_id}"
        params = {"with": "contacts"}
        
        try:
            response = requests.get(url, headers=self._get_headers(), params=params)
            if response.status_code == 200:
                contacts = response.json().get("_embedded", {}).get("contacts", [])
                if not contacts:
                    return None
                
                # Kontakt ID orqali telefonni olish
                contact_id = contacts[0].get("id")
                c_url = f"{self.base_url}/api/v4/contacts/{contact_id}"
                c_resp = requests.get(c_url, headers=self._get_headers())
                if c_resp.status_code == 200:
                    fields = c_resp.json().get("custom_fields_values", [])
                    for field in fields:
                        if field.get("field_code") == "PHONE":
                            return field.get("values", [{}])[0].get("value")
            return None
        except Exception as e:
            logger.error(f"[AMOCRM GET PHONE ERROR] {e}")
            return None
    def update_lead_responsible(self, lead_id: int, responsible_user_id: int):
        """
        Lidning mas'ul shaxsini yangilash.
        """
        self._load_token()
        url = f"{self.base_url}/api/v4/leads/{lead_id}"
        headers = self._get_headers()
        data = {
            "responsible_user_id": int(responsible_user_id)
        }
        
        try:
            response = requests.patch(url, headers=headers, json=data)
            if response.status_code == 200:
                logger.info(f"[AMOCRM UPDATE] Lead {lead_id} assigned to user {responsible_user_id}")
                return True
            else:
                logger.error(f"[AMOCRM UPDATE ERROR] {response.status_code}: {response.text}")
                return False
        except Exception as e:
            logger.error(f"[AMOCRM UPDATE EXCEPTION] {e}")
            return False
    def update_contact_phone(self, name, phone):
        """Kontaktning telefon raqamini yangilash."""
        self._load_token()
        # 1. Kontaktni qidirish
        search_url = f"{self.base_url}/api/v4/contacts"
        params = {"query": name}
        headers = self._get_headers()
        
        try:
            resp = requests.get(search_url, headers=headers, params=params)
            if resp.status_code == 200:
                contacts = resp.json().get("_embedded", {}).get("contacts", [])
                if not contacts:
                    return False
                
                contact_id = contacts[0].get("id")
                update_url = f"{self.base_url}/api/v4/contacts/{contact_id}"
                data = {
                    "custom_fields_values": [
                        {
                            "field_code": "PHONE",
                            "values": [
                                {"value": phone, "enum_code": "MOB"}
                            ]
                        }
                    ]
                }
                upd_resp = requests.patch(update_url, headers=headers, json=data)
                return upd_resp.status_code == 200
            return False
        except Exception as e:
            logger.error(f"[AMOCRM UPDATE PHONE ERROR] {e}")
            return False
    def get_contact_by_phone(self, phone: str) -> Optional[dict]:
        """Suhbatdoshni telefon raqami orqali qidirish."""
        if not phone or phone == "Raqam yo'q":
            return None
            
        self._load_token()
        url = f"{self.base_url}/api/v4/contacts"
        params = {"query": phone}
        
        try:
            response = requests.get(url, headers=self._get_headers(), params=params)
            if response.status_code == 200:
                contacts = response.json().get("_embedded", {}).get("contacts", [])
                if contacts:
                    return contacts[0]
            return None
        except Exception as e:
            logger.error(f"[AMOCRM SEARCH PHONE ERROR] {e}")
            return None

    def add_contact_note(self, contact_id: int, text: str):
        """Kontaktga izoh (primicheniya) qo'shish."""
        self._load_token()
        url = f"{self.base_url}/api/v4/contacts/{contact_id}/notes"
        data = [
            {
                "note_type": "common",
                "params": {
                    "text": text
                }
            }
        ]
        
        try:
            response = requests.post(url, headers=self._get_headers(), json=data)
            if response.status_code == 201:
                logger.info(f"[AMOCRM OK] Kontaktga izoh qo'shildi: {contact_id}")
                return True
            else:
                logger.error(f"[AMOCRM NOTE ERROR] {response.status_code}: {response.text}")
                return False
        except Exception as e:
            logger.error(f"[AMOCRM NOTE EXCEPTION] {e}")
            return False

if __name__ == "__main__":
    # Test
    logging.basicConfig(level=logging.INFO)
    # amocrm = AmoCRMSync("sub", "id", "secret", "url")
    # amocrm.create_lead("Test User", "+998901234567", 50000)
