import paramiko
import os
import sys

# Force UTF-8 encoding for output
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# Using the credentials from deploy_creds.py as it seems more specific
HOST = "109.199.100.137"
USER = "root"
PASSWORD = "#8tV9Hsm0aMqapdb"
REMOTE_DIR = "/root/telegram_bot"

files_to_sync = [
    'userbot.py', 
    'config.py', 
    'database.py', 
    'gsheets.py', 
    'training_data.txt', 
    '.env', 
    'service_account.json', 
    'requirements.txt',
    'gcontacts.py', 
    'gcalendar.py', 
    'amocrm_sync.py', 
    'learning_engine.py',
    'tts_engine.py', 
    'invoicing.py', 
    'emoji_sync.py'
]

def deploy():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        print(f"Connecting to {HOST}...")
        ssh.connect(HOST, username=USER, password=PASSWORD)
        print("Connected!")
        
        sftp = ssh.open_sftp()
        for f in files_to_sync:
            if os.path.exists(f):
                remote_path = f"{REMOTE_DIR}/{f}"
                print(f"Uploading {f} -> {remote_path}...")
                sftp.put(f, remote_path)
            else:
                print(f"Warning: {f} not found locally.")
        
        sftp.close()
        
        print("Restarting Docker Compose to apply changes...")
        # We use docker compose restart to ensure the container picks up updated files
        # If it's running via python directly in the container, restart is sufficient
        stdin, stdout, stderr = ssh.exec_command(f"cd {REMOTE_DIR} && docker compose restart")
        stdout.channel.recv_exit_status()
        
        print("Deployment completed successfully!")
        
    except Exception as e:
        print(f"Deployment failed: {e}")
    finally:
        ssh.close()

if __name__ == "__main__":
    deploy()
