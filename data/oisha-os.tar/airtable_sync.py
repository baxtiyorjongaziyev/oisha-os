import requests
import logging
import os
from datetime import datetime

logger = logging.getLogger(__name__)

class AirtableSync:
    def __init__(self, api_key=None, base_id=None, table_name="Projects"):
        self.api_key = api_key or os.getenv("AIRTABLE_API_KEY")
        self.base_id = base_id or os.getenv("AIRTABLE_BASE_ID")
        self.table_name = table_name
        self.endpoint = f"https://api.airtable.com/v0/{self.base_id}/{self.table_name}"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

    def get_projects(self):
        """Airtable-dan loyihalarni olish."""
        if not self.api_key or not self.base_id:
            logger.error("[AIRTABLE] API key yoki Base ID yetishmayapti.")
            return []

        try:
            response = requests.get(self.endpoint, headers=self.headers)
            if response.status_code == 200:
                data = response.json()
                return data.get("records", [])
            else:
                logger.error(f"[AIRTABLE ERROR] {response.status_code}: {response.text}")
                return []
        except Exception as e:
            logger.error(f"[AIRTABLE EXCEPTION] {e}")
            return []

    def get_overdue_projects(self):
        """Muddati o'tgan loyihalarni topish."""
        projects = self.get_projects()
        overdue = []
        now = datetime.now()
        
        for p in projects:
            fields = p.get("fields", {})
            deadline_str = fields.get("Deadline")
            stage = fields.get("Stage")
            
            if deadline_str and stage not in ["Done", "Completed", "Topshirildi"]:
                try:
                    deadline = datetime.strptime(deadline_str, "%Y-%m-%d")
                    if deadline < now:
                        overdue.append(p)
                except Exception:
                    continue
        return overdue

    def get_projects_by_stage(self, stage_name: str):
        """Ma'lum bir bosqichdagi loyihalarni olish."""
        projects = self.get_projects()
        return [p for p in projects if p.get("fields", {}).get("Stage") == stage_name]

    def get_finance_records(self, table_name="Finance"):
        """Moliya jadvalidan barcha tranzaksiyalarni olish."""
        original_table = self.table_name
        self.table_name = table_name
        self.endpoint = f"https://api.airtable.com/v0/{self.base_id}/{self.table_name}"
        
        try:
            records = self.get_projects() # Qayta ishlatamiz nomiga qaramay
            return records
        finally:
            # Table nomini asliga qaytarish
            self.table_name = original_table
            self.endpoint = f"https://api.airtable.com/v0/{self.base_id}/{self.table_name}"

    def update_project_fields(self, record_id: str, fields: dict):
        """Loyihaning bir nechta maydonlarini yangilash."""
        url = f"{self.endpoint}/{record_id}"
        data = {"fields": fields}
        try:
            response = requests.patch(url, headers=self.headers, json=data)
            return response.status_code == 200
        except Exception as e:
            logger.error(f"[AIRTABLE UPDATE ERROR] {e}")
            return False

    def update_project_stage(self, record_id, next_stage):
        """Loyihaning bosqichini yangilash."""
        return self.update_project_fields(record_id, {"Stage": next_stage})

if __name__ == "__main__":
    # Test
    sync = AirtableSync()
    projects = sync.get_projects()
    print(f"Found {len(projects)} projects.")
