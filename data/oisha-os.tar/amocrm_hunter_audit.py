import asyncio
import logging
import sys
import requests

project_dir = r"c:\Users\baxti\.gemini\antigravity\playground\oisha-os"
sys.path.append(project_dir)

import settings
import amocrm_sync

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("hunter_audit")

async def check_hunter():
    amocrm = amocrm_sync.AmoCRMSync(
        subdomain=settings.settings.AMOCRM_SUBDOMAIN,
        client_id=settings.settings.AMOCRM_CLIENT_ID,
        client_secret=settings.settings.AMOCRM_CLIENT_SECRET.get_secret_value() if settings.settings.AMOCRM_CLIENT_SECRET else None,
        redirect_url=settings.settings.AMOCRM_REDIRECT_URL
    )
    
    amocrm._load_token()
    headers = amocrm._get_headers()
    
    url = f"{amocrm.base_url}/api/v4/leads/pipelines/10117998"
    res = requests.get(url, headers=headers)
    if res.status_code == 200:
        p = res.json()
        name = p.get("name")
        p_id = p.get("id")
        logger.info(f"PIPELINE: {name} (ID: {p_id})")
        statuses = p.get("_embedded", {}).get("statuses", [])
        for s in statuses:
            logger.info(f"  - Stage: {s.get('name')} (ID: {s.get('id')})")
    else:
        logger.error(f"Failed to fetch pipeline: {res.status_code}")

if __name__ == "__main__":
    asyncio.run(check_hunter())
