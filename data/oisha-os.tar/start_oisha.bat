@echo off
cd /d "c:\Users\baxti\.gemini\antigravity\playground\oisha-os"
echo Starting Oisha-OS Enterprise AI...
"C:\Users\baxti\AppData\Local\Microsoft\WindowsApps\PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\python.exe" userbot.py
