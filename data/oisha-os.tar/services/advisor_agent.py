
import logging
import datetime
from typing import Optional, List, Dict, Any
from google import genai
from google.genai import types

logger = logging.getLogger(__name__)

class AdvisorAgent:
    """
    Shadow Advisor (Coach Mode) that listens to private chats and 
    provides strategic advice + action suggestions to the owner.
    """

    def __init__(self, api_key: str, db, action_parser):
        self.client = genai.Client(api_key=api_key)
        self.db = db
        self.action_parser = action_parser
        self.model_name = "gemini-2.0-flash"

    async def analyze_and_advise(self, chat_id: int, message_text: str, history_context: str, sender_name: str) -> Optional[str]:
        """
        Analyzes the conversation and returns a strategic tip/action if necessary.
        """
        
        system_instruction = f"""
        Sizning ismingiz Oisha-OS. Siz @baxtiyor_uz (user) uchun shaxsiy Strategik Mentor va Biznes Coachsiz.
        Hozir user "{sender_name}" ismli shaxs bilan Telegramda xususiy (DM) suhbatlashmoqda.
        
        Sizning vazifangiz:
        1. Suhbatni diqqat bilan kuzatish (Shadow Mode).
        2. Userning suhbatiga ARALASHMASLIK (unga ruxsatsiz yozmaslik).
        3. Faqat userning o'ziga (Baxtiyorga) maslahat yoki texnik yordam taklif qilish.
        
        Tahlil qilish qoidalari:
        - Agar uchrashuv (meeting), vaqt yoki joy haqida gap ketsa, [CALENDAR_EVENT: summary=...|start=...] shaklida taklif bering.
        - Agar user biror narsani va'da qilsa, [TASK: description=...] shaklida xodimlar uchun yoki o'zi uchun vazifa taklif qiling.
        - **Kontaktni boyitish:** Agar suhbatdoshning ismi yoki raqami yo'q bo'lsa, uni ELEGANT (chiroyli) tarzda so'rash uchun tayyor skript taklif qiling. (Masalan: "Qizlarimiz vaqtni kelishishlari uchun qaysi raqamingizga bog'lanishsa qulay bo'ladi?").
        - Suhbat ohangi bo'yicha taktik maslahat bering (masalan: "U biroz ikkilanyapti, unga kafolat bering").
        - Agar maslahat berishga arzirli narsa bo'lmasa, FAQAT bo'sh joy qaytaring.
        
        Javob formati (o'zbek tilida, do'stona va professional):
        💡 [MASLAHAT MATNI]
        [ACTION_TAGS_IF_ANY]
        """

        contents = [
            f"Suhbat tarixi (oxirgi xabarlar):\n{history_context}\n\nYangi xabar: \"{message_text}\""
        ]

        try:
            # Using synchronous-looking API but in the new SDK it supports async through wrappers or 
            # we just call it directly as it's a small blocking call in a task.
            # However, for userbot safety, we'll try to keep it non-blocking.
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=contents,
                config=types.GenerateContentConfig(
                    system_instruction=system_instruction
                )
            )
            
            if response.text and len(response.text.strip()) > 5:
                # Filter out pure hallucinations if AI tried to "reply" as Oisha
                return response.text.strip()
        except Exception as e:
            logger.error(f"[ADVISOR] Analysis error: {e}")
            
        return None

    def should_notify(self, chat_id: int, message_id: int, advice_content: str) -> bool:
        """Checks if this advice was already sent to avoid spam."""
        try:
            conn = self.db.get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM advisor_logs WHERE chat_id = ? AND message_id = ?", (chat_id, message_id))
            exists = cursor.fetchone()
            if exists:
                return False
            
            # Log it now
            cursor.execute(
                "INSERT INTO advisor_logs (chat_id, message_id, advice_type, content, created_at) VALUES (?, ?, ?, ?, ?)",
                (chat_id, message_id, 'tactical', advice_content, datetime.datetime.now())
            )
            conn.commit()
            return True
        except Exception as e:
            logger.error(f"[ADVISOR] DB check error: {e}")
            return True
