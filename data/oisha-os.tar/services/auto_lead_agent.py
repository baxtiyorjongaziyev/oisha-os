
import logging
import json
import datetime
from typing import Optional, Dict, Any
from google import genai
from google.genai import types

logger = logging.getLogger(__name__)

class AutoLeadAgent:
    """
    Agent that analyzes incoming Telegram messages to extract lead information
    for automatic AmoCRM synchronization.
    """

    def __init__(self, api_key: str):
        self.client = genai.Client(api_key=api_key)
        self.model_name = "gemini-2.0-flash"

    async def extract_lead_info(self, message_text: str, user_profile: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Parses the message and user profile to extract structured lead data.
        """
        
        system_instruction = """
        Siz Oisha-OS Elite Lead Analyzer xizmatisiz. 
        Vazifangiz: Mijozning Telegram xabarini tahlil qilib, AmoCRM uchun ma'lumot chiqarish.
        
        Quyidagi JSON formatda javob bering:
        {
          "is_lead": boolean, (Agar xabarda biznes, hamkorlik, dizayn, IT, marketing, reklama yoki biror loyiha haqida kichik bo'lsa ham qiziqish bo'lsa true)
          "first_name": string,
          "last_name": string,
          "phone": string,
          "business": string, (Mijozning sohasi yoki mavzusi)
          "needs": string, (Mijozning ehtiyoji/so'rovi)
          "confidence_score": number (0-100)
        }
        
        MUHIM (Filtrni yumshating): 
        - Agar foydalanuvchi "Logo", "Branding", "Sayt", "Dizayn", "Marketing", "Random Coffee" yoki "Uchrashuv" so'zlarini aytgan bo'lsa, uni ALBATTA lead deb hisoblang.
        - Faqat oilaviy yoki o'ta shaxsiy do'stona (biznesga aloqasiz) suhbatlarni false qiling.
        
        Faqat JSON qaytaring.
        """

        prompt = f"""
        Mijoz Profili: {json.dumps(user_profile)}
        Xabar matni: "{message_text}"
        """

        try:
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=[prompt],
                config=types.GenerateContentConfig(
                    system_instruction=system_instruction,
                    response_mime_type="application/json"
                )
            )
            
            if response.text:
                data = json.loads(response.text)
                if data.get("is_lead") and data.get("confidence_score", 0) > 50:
                    return data
        except Exception as e:
            logger.error(f"[AUTO_LEAD] Error extracting info: {e}")
            
        return None
