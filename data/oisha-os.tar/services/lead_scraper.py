import asyncio
import logging
import json
import os
import random
from telethon import TelegramClient, functions, types
from services.google_service import GoogleService
from settings import settings
import google.generativeai as genai

logger = logging.getLogger(__name__)

class LeadScraper:
    """Enriched & Safe Lead Scraping from Telegram Forum Topics."""

    def __init__(self, google_service, db, client=None, amocrm=None):
        self.google = google_service
        self.db = db
        self.client = client
        self.amocrm = amocrm
        
        # Configure Gemini
        genai.configure(api_key=settings.GEMINI_API_KEY.get_secret_value())
        self.model = genai.GenerativeModel('gemini-2.0-flash')

    def _is_processed(self, msg_id):
        if self.db:
            return self.db.is_message_processed(msg_id)
        return False

    def _mark_processed(self, msg_id, chat_id, status='synced', reason=None):
        if self.db:
            self.db.mark_message_processed(msg_id, chat_id, status, reason)

    async def parse_intro_with_ai(self, text: str):
        """Use AI to extract structured info and FILTER for relevance."""
        prompt = f"""
        Quyidagi Telegram xabaridan foydalanuvchi ma'lumotlarini ajratib oling.
        
        DIQQAT: Sizning vazifangiz nafaqat ma'lumot yig'ish, balki FILTRLASH hamdir.
        Faqat Jon Branding va Oisha-OS agentligi uchun RELEVANT bo'lgan (qiziqish bildirgan) foydalanuvchilarni aniqlang.
        
        RELEVANT sohalar:
        - Branding, Rebranding, Logo, Dizayn xizmatlari.
        - Marketing, SMM, Reklama.
        - IT, Sayt yaratish, CRM, Avtomatizatsiya, AI botlar.
        - Biznesni raqamlashtirish bo'yicha ehtiyojlar.
        
        Agar foydalanuvchi maqsadi ushbu sohalarga umuman mos kelmasa (masalan: un sotish, kiyim sotish, qurilish materiallari), "is_relevant" maydonini false qiling.
        
        Faqat JSON formatida javob bering:
        {{
            "is_relevant": true/false,
            "relevance_reason": "Nega relevant yoki nega emasligi haqida qisqa izoh",
            "first_name": "Ism",
            "last_name": "Familya (agar bo'lsa)",
            "phone": ["+998...", "+998..."],
            "business": "Biznes sohasi",
            "needs": "Ehtiyojlari yoki nima qidirayotgani"
        }}
        
        Xabar:
        {text}
        """
        try:
            response = self.model.generate_content(prompt)
            raw_json = response.text.strip().replace('```json', '').replace('```', '')
            return json.loads(raw_json)
        except Exception as e:
            logger.error(f"[AI] Parsing error: {e}")
            return None

    async def sync_topic_to_contacts(self, client: TelegramClient, group_id: int, topic_id: int, limit: int = 25):
        """Extract leads from a specific forum topic and sync to Google Contacts."""
        logger.info(f"[SCRAPER] Topic {topic_id} tahlili boshlandi... 👸🛡️")
        
        saved_count = 0
        
        # Fetch messages specifically from this topic
        async for message in client.iter_messages(group_id, reply_to=topic_id):
            if not message.text or self._is_processed(message.id):
                continue
            
            if saved_count >= limit:
                logger.info(f"[SCRAPER] Kunlik limitga ({limit}) yetildi. 🛑")
                break

            logger.info(f"[SCRAPER] Xabar tahlil qilinmoqda: MessageID {message.id}")
            
            # AI Analysis
            data = await self.parse_intro_with_ai(message.text)
            
            # CHECK RELEVANCE
            if not data or not data.get('is_relevant'):
                reason = data.get('relevance_reason') if data else 'AI Xatosi'
                logger.info(f"[SCRAPER] Lead tashlab yuborildi (Irrelevant): {reason}")
                self._mark_processed(message.id, group_id, status='irrelevant', reason=reason)
                continue

            if data and data.get('phone'):
                # Handle multiple phones
                phones = data.get('phone')
                if isinstance(phones, str):
                    phones = [p.strip() for p in phones.replace(',', ' ').replace('/', ' ').split() if p.strip()]
                
                # Use primary phone for logic
                primary_phone = phones[0] if phones else None
                if not primary_phone:
                    self._mark_processed(message.id, group_id, status='skipped', reason='No valid phone found')
                    continue

                # Fallback for name from Telegram if AI failed
                sender = await message.get_sender()
                name = data.get('first_name')
                if not name or name.lower() == 'unknown':
                    name = getattr(sender, 'first_name', None) or getattr(sender, 'username', 'Unknown')
                
                surname = data.get('last_name') or getattr(sender, 'last_name', '')
                full_name = f"{name} {surname} TN5 Gr".strip()
                bio = f"Biznes: {data.get('business', 'Noʻmalum')}\nEhtiyoj: {data.get('needs', 'Noʻmalum')}\n\nOriginal: {message.text[:200]}..."
                
                logger.info(f"[SCRAPER] Saqlanmoqda: {full_name} ({', '.join(phones)})")
                
                try:
                    # 1. Save to Google Contacts (Personal) - Pass the list of phones
                    await self.google.save_contact(full_name, phones, notes=bio)
                    
                    # CRM Sync if enabled
                    if self.amocrm:
                        self.amocrm.create_lead(
                            name=full_name,
                            price=0,
                            responsible_user_id=settings.OWNER_ID,
                            status_id=None
                        )
                    
                    # 2. Add to Telegram Contacts (Real Sync)
                    try:
                        await client(functions.contacts.AddContactRequest(
                            id=message.sender_id,
                            first_name=name,
                            last_name=f"{surname} TN5 Gr",
                            phone=primary_phone,
                            add_phone_privacy_exception=True
                        ))
                        logger.info(f"[SCRAPER] Telegram kontakt qo'shildi: {full_name}")
                    except Exception as tg_ex:
                        logger.warning(f"[SCRAPER] Telegram kontakt qo'shishda xato: {tg_ex}")

                    saved_count += 1
                    self._mark_processed(message.id, group_id, status='synced')
                    
                    # ULTRA SAFE DELAY: 60 - 120 seconds
                    wait_time = random.uniform(60, 120)
                    logger.info(f"[SCRAPER] Xavfsiz tanaffus: {wait_time:.1f} soniya... 🐢🛡️")
                    await asyncio.sleep(wait_time)
                    
                except Exception as ex:
                    logger.error(f"[SCRAPER] Sync error: {ex}")
                    # Don't mark as processed if there was a major sync error, to retry later
            else:
                # No phone found
                self._mark_processed(message.id, group_id, status='skipped', reason='No phone matched')

        return saved_count

    async def sync_all_group_members(self, client: TelegramClient, group_id: int):
        """Ommaiy tarzda guruhdagi barcha a'zolarni to'g'ridan-to'g'ri (AI filtrlashsiz) saqlash."""
        logger.info(f"[MASS SYNC] {group_id} guruhining barcha a'zolarini skanerlash boshlandi... 👸🛡️")
        
        saved_count = 0
        try:
            async for user in client.iter_participants(group_id):
                if user.bot or user.deleted:
                    continue
                
                # Biz message_id xotirasiga mass sync odamlarini kiritamiz
                # dummy_msg_id = user_id * (-1) qilib qo'shsak to'qnashmaydi
                dummy_msg_id = user.id * -1
                if self._is_processed(dummy_msg_id):
                    continue
                
                name = getattr(user, 'first_name', '') or ''
                surname = getattr(user, 'last_name', '') or ''
                username = getattr(user, 'username', '') or ''
                phone = getattr(user, 'phone', None)
                
                if not name and not surname:
                    name = username or f"User {user.id}"

                full_name = f"{name} {surname}".strip()
                
                # Kirilchani lotinchaga ogirish lug'ati
                cyrillic_to_latin_map = {
                    'А':'A', 'Б':'B', 'В':'V', 'Г':'G', 'Д':'D', 'Е':'E', 'Ё':'Yo', 'Ж':'J', 'З':'Z',
                    'И':'I', 'Й':'Y', 'К':'K', 'Л':'L', 'М':'M', 'Н':'N', 'О':'O', 'П':'P', 'Р':'R',
                    'С':'S', 'Т':'T', 'У':'U', 'Ф':'F', 'Х':'X', 'Ц':'Ts', 'Ч':'Ch', 'Ш':'Sh', 'Щ':'Sh',
                    'Ъ':'', 'Ы':'I', 'Ь':'', 'Э':'E', 'Ю':'Yu', 'Я':'Ya',
                    'а':'a', 'б':'b', 'в':'v', 'г':'g', 'д':'d', 'е':'e', 'ё':'yo', 'ж':'j', 'з':'z',
                    'и':'i', 'й':'y', 'к':'k', 'л':'l', 'м':'m', 'н':'n', 'о':'o', 'п':'p', 'р':'r',
                    'с':'s', 'т':'t', 'у':'u', 'ф':'f', 'х':'x', 'ц':'ts', 'ч':'ch', 'ш':'sh', 'щ':'sh',
                    'ъ':'', 'ы':'i', 'ь':'', 'э':'e', 'ю':'yu', 'я':'ya', 'ў':'o\'', 'қ':'q', 'ғ':'g\'', 'ҳ':'h',
                    'Ў':'O\'', 'Қ':'Q', 'Ғ':'G\'', 'Ҳ':'H'
                }
                
                # Lotin harflariga o'tqazish
                for cyr, lat in cyrillic_to_latin_map.items():
                    full_name = full_name.replace(cyr, lat)
                    name = name.replace(cyr, lat)
                    surname = surname.replace(cyr, lat)
                
                # Oxiriga TN5 Gr qo'shish
                full_name = f"{full_name} TN5 Gr".strip()
                
                if not phone:
                    phones = []
                else:
                    phones = [phone if phone.startswith('+') else f"+{phone}"]

                try:
                    logger.info(f"[MASS SYNC] Tahlil: {full_name} ({phone or 'No phone'})")
                    # 1. Google Contacts-ga "TEZ NATIJA 5" tegi bilan
                    await self.google.save_contact(
                        name=full_name, 
                        phones=phones, 
                        notes=f"TG Username: @{username}\nTG ID: {user.id}", 
                        group_name="TEZ NATIJA 5"
                    )
                    
                    # 2. Telegram Contacts-ga (har doim qo'shish, raqam bo'lmasa ham)
                    try:
                        await client(functions.contacts.AddContactRequest(
                            id=user.id,
                            first_name=name,
                            last_name=surname or "TN5 Gr",
                            phone=phones[0] if phones else "",
                            add_phone_privacy_exception=True
                        ))
                        logger.info(f"[MASS SYNC] Telegramga qo'shildi: {full_name}")
                    except Exception as tg_ex:
                        logger.warning(f"[MASS SYNC] TG xatosi: {tg_ex}")

                    # 3. AmoCRM-da yangi bitim yaratish (Potensial mijoz)
                    if self.amocrm:
                        try:
                            # 'Potensial mijoz' nomli bitim yaratish
                            # Hunter pipeline ID ni ishlatamiz (agar bo'lsa)
                            self.amocrm.create_lead(
                                name=f"Potential: {full_name}",
                                price=0,
                                responsible_user_id=settings.OWNER_ID, # Bot egasiga biriktirish
                                status_id=None # Default status
                            )
                            logger.info(f"[MASS SYNC] AmoCRM bitim yaratildi: {full_name}")
                        except Exception as amo_ex:
                            logger.warning(f"[MASS SYNC] AmoCRM xatosi: {amo_ex}")
                    else:
                        logger.warning("[MASS SYNC] AmoCRM service not initialized in LeadScraper")

                    self._mark_processed(dummy_msg_id, group_id, status='synced_mass')
                    saved_count += 1
                    
                    # Banning prevention!
                    wait_time = random.uniform(30.0, 90.0)
                    logger.info(f"[MASS SYNC] Kutish: {wait_time:.1f} soniya... 🐢🛡️")
                    await asyncio.sleep(wait_time)
                    
                except Exception as e:
                    logger.error(f"[MASS SYNC] Saqlashda xato: {e}")
                    
            logger.info(f"[MASS SYNC] Yakunlandi! Jami ommaviy saqlanganlar: {saved_count}")
        except Exception as ex:
            logger.error(f"[MASS SYNC ERROR] {ex}")
        return saved_count

    async def sync_private_dialogs(self, client: TelegramClient, limit: int = 100):
        """Oxirgi shaxsiy suhbatlardan (DM) lidlarni qidirib topish va AmoCRMga qo'shish."""
        logger.info(f"[SCRAPER] Shaxsiy suhbatlar (DM) tahlili boshlandi (Limit: {limit})... 👸🛡️")
        
        sync_count = 0
        from services.auto_lead_agent import AutoLeadAgent
        from settings import settings
        auto_lead_agent = AutoLeadAgent(api_key=settings.GEMINI_API_KEY.get_secret_value())

        async for dialog in client.iter_dialogs(limit=limit):
            if not dialog.is_user or dialog.entity.bot:
                continue

            user_id = dialog.id
            if self.db.is_crm_synced(user_id):
                continue
            
            messages = []
            async for msg in client.iter_messages(user_id, limit=10):
                if msg.text:
                    messages.append(msg.text)
            
            if not messages:
                continue
            
            full_context = "\n".join(reversed(messages))
            first_name = getattr(dialog.entity, 'first_name', 'User')
            last_name = getattr(dialog.entity, 'last_name', '')
            username = getattr(dialog.entity, 'username', 'no_username')
            
            # BLACKLIST CHECK
            full_name = f"{first_name} {last_name}".strip()
            if any(name.lower() in full_name.lower() for name in settings.EXCLUDED_NAMES):
                logger.info(f"[SCRAPER] SKIPPED (Blacklisted Name): {full_name}")
                continue
                
            user_profile = {
                "id": user_id,
                "first_name": first_name,
                "username": username
            }
            
            logger.info(f"[SCRAPER] Tahlil qilinmoqda: {full_name} (ID: {user_id})")
            
            # Official Telegram data: Entity phone
            tg_phone = getattr(dialog.entity, 'phone', None)
            
            lead_data = await auto_lead_agent.extract_lead_info(full_context, user_profile)
            
            if lead_data and lead_data.get("is_lead"): # is_lead ishlatyapmiz extract_lead_info'da
                # DESIGNER/ROLE CHECK
                business_type = lead_data.get('business', '').lower()
                needs = lead_data.get('needs', '').lower()
                if any(role.lower() in business_type or role.lower() in needs for role in settings.EXCLUDED_ROLES):
                    logger.info(f"[SCRAPER] SKIPPED (Blacklisted Role): {full_name} - {business_type}")
                    continue

                name = f"{lead_data.get('first_name', first_name)} {lead_data.get('last_name', '')}".strip()
                # PRIORITY: 1. TG Profile, 2. AI Extract
                phone = tg_phone or lead_data.get("phone")
                note_text = f"Retro-Sync:\nBiznes: {lead_data.get('business')}\nEhtiyoj: {lead_data.get('needs')}"
                
                if not tg_phone and not lead_data.get("phone"):
                    note_text += "\n⚠️ [RAQAM YO'Q] Profil va xabarda raqam topilmadi."

                try:
                    if self.amocrm:
                        # DEDUPLICATION CHECK
                        existing_contact = self.amocrm.get_contact_by_phone(phone)
                        if existing_contact:
                            logger.info(f"[SCRAPER] DEDUPE: Contact {name} ({phone}) exists. Adding note.")
                            self.amocrm.add_contact_note(existing_contact['id'], f"Qayta murojaat (Retro-Sync):\n{note_text}")
                        else:
                            # amocrm.create_lead is synchronous
                            self.amocrm.create_lead(
                                name=name,
                                phone=phone or "Raqam yo'q",
                                note=note_text
                            )
                    
                    if self.google:
                        await self.google.save_contact(name, [phone] if phone else [], notes=note_text)
                        
                    self.db.mark_crm_synced(user_id)
                    sync_count += 1
                    logger.info(f"✅ [RETRO SYNC OK] {name} qo'shildi!")
                    await asyncio.sleep(random.uniform(5, 10))
                except Exception as ex:
                    logger.error(f"❌ [RETRO SYNC ERROR] {ex}")
        
        return sync_count
