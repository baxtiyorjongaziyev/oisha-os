
import logging
from gsheets import GoogleSheetsSync
from gcalendar import GoogleCalendarSync
from gcontacts import GoogleContactsSync
import config

logger = logging.getLogger(__name__)

class GoogleService:
    """Google Sheets, Calendar va Contacts xizmatlarini birlashtirgan modul."""
    
    def __init__(self):
        self.sheets = GoogleSheetsSync(config.GSHEET_ID, config.GSHEET_CREDS_FILE)
        self.calendar = GoogleCalendarSync(config.GSHEET_CREDS_FILE)
        self.contacts = GoogleContactsSync(config.GSHEET_CREDS_FILE)

    async def log_user_action(self, user_id: int, name: str, action: str):
        """Foydalanuvchi amalni GSheet-ga yozish."""
        self.sheets.log_message(user_id, action, is_ai=False)

    async def schedule_meeting(self, summary: str, start_time: str, end_time: str = None):
        """Google Calendar-da uchrashuv belgilash."""
        return self.calendar.create_event(summary, start_time, end_time)

    async def save_contact(self, name: str, phones: list, notes: str = None, group_name: str = "TEZ NATIJA 5"):
        """Google Contacts-ga saqlash (Bir nechta raqam va Label bilan)."""
        # Split name into first and last if possible for better sync
        parts = name.split()
        first = parts[0] if parts else "Unknown"
        last = " ".join(parts[1:]) if len(parts) > 1 else ""
        return self.contacts.create_contact(first, last, phones, notes, group_name)
