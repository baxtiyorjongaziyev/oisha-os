import logging
import datetime
import json
from typing import Dict, Any, List
from database import Database
from services.crm_service import CRMService

logger = logging.getLogger(__name__)

class EnterpriseReporter:
    """Jamoa samaradorligi va Plan-Fakt hisobotlarini tayyorlash xizmati."""

    def __init__(self, db: Database, crm: CRMService, airtable=None):
        self.db = db
        self.crm = crm
        self.airtable = airtable
        # Standart statuslar (AmoCRM defaults)
        self.WON_STATUS = 142
        self.LOST_STATUS = 143

    def get_daily_efficiency_report(self):
        """Kunlik hisobot: faqat bugungi o'zgarishlar va umumiy holat."""
        now = datetime.datetime.now()
        today_str = now.strftime('%Y-%m-%d')
        month_str = now.strftime('%Y-%m')
        report = [f"📊 <b>KUNLIK ENTERPRISE HISOBOT</b> ({today_str})\n"]
        
        # 1. SALES (AmoCRM)
        if self.crm:
            # Bugungi yopilgan bitimlar (Won)
            # BU YERDA REAL AMOCRM API CHAQUVI KERAK (get_leads_by_status or similar for today)
            report.append(f"💰 <b>Sales (Bugun):</b>")
            report.append(f"- Yangi lidlar: <i>Hozircha hisoblanmoqda...</i>")
            
            # Plan-Fakt (Monthly context)
            month_str = now.strftime('%Y-%m')
            targets = self.db.get_department_targets(month_str)
            sales_target = next((t['value'] for t in targets if t['dept'] == 'Sales'), 0)
            if sales_target > 0:
                report.append(f"- Oylik reja: {sales_target:,.0f} so'm")
        
        # 2. PM (Airtable)
        if self.airtable:
            # Bugun bitgan yoki o'zgargan loyihalar
            report.append(f"\n🏗 <b>Production (Bugun):</b>")
            projects = self.airtable.get_projects()
            report.append(f"- Aktiv loyihalar: {len(projects)} ta")
            
        # 3. FINANCE (Airtable)
        if self.airtable:
            finance_records = self.airtable.get_finance_records()
            today_income = 0
            today_expense = 0
            
            for rec in finance_records:
                f = rec.get("fields", {})
                date_str = f.get("Sana") or f.get("Date")
                if date_str == today_str:
                    amount = f.get("Summa") or 0
                    turi = f.get("Turi") or ""
                    if "Daromad" in turi or "Income" in turi:
                        today_income += amount
                    elif "Xarajat" in turi or "Expense" in turi:
                        today_expense += amount
            
            if today_income > 0 or today_expense > 0:
                report.append(f"\n💰 <b>Moliya (Bugun):</b>")
                report.append(f"- Kirim: {today_income:,.0f} so'm".replace(',', ' '))
                report.append(f"- Chiqim: {today_expense:,.0f} so'm".replace(',', ' '))
                report.append(f"- Net Foyda: <b>{(today_income - today_expense):,.0f} so'm</b>".replace(',', ' '))
            
        report.append("\n🌙 <i>Bugungi kun uchun rahmat! Ertaga yanada yaxshiroq bo'lamiz.</i>")
        return "\n".join(report)

    async def get_team_efficiency_report(self) -> str:
        """Jamoa va bo'limlar uchun umumiy samaradorlik hisoboti."""
        now = datetime.datetime.now()
        month_str = now.strftime('%Y-%m')
        
        report = []
        report.append("🏢 <b>Oisha-OS: Enterprise Audit</b>")
        report.append(f"⏱ <i>Hisobot vaqti: {now.strftime('%Y-%m-%d %H:%M')}</i>\n")

        # 1. SALES & MARKETING (AmoCRM)
        # Reja-fakt hisoblash
        targets = self.db.get_department_targets(month_str)
        sales_target = next((t['value'] for t in targets if t['dept'] == 'Sales'), 80_000_000)
        
        leads = await self.crm.amocrm.get_leads_detailed(limit=100)
        
        # Oylik yopilgan bitimlar summasi (Fact)
        # Eslatma: AmoCRM API limitlari tufayli 'Won' larni alohida filtrlab olish kerak bo'lishi mumkin
        won_leads = [l for l in leads if l.get('status_id') == self.WON_STATUS]
        total_won_sum = sum(l.get('price', 0) for l in won_leads)
        
        active_leads = len([l for l in leads if l.get('status_id') not in [self.WON_STATUS, self.LOST_STATUS]])
        
        report.append(f"💰 <b>Sales Performance:</b>")
        report.append(f"- Oylik Reja: {sales_target:,.0f} so'm".replace(',', ' '))
        report.append(f"- Amalda (Won): {total_won_sum:,.0f} so'm".replace(',', ' '))
        
        progress_pct = (total_won_sum / sales_target * 100) if sales_target > 0 else 0
        report.append(f"- Reja bajarilishi: <b>{progress_pct:.1f}%</b> {'✅' if progress_pct >= 100 else '📈'}")
        report.append(f"- Aktiv lidlar: {active_leads} ta")

        # 2. MARKETING (Channels)
        # Manbalar tahlili (Tags orqali)
        channels = {}
        for l in leads:
            # AmoCRM tags structure: _embedded.tags
            tags = l.get('_embedded', {}).get('tags', [])
            for tag in tags:
                tag_name = tag.get('name', 'Noma\'lum')
                channels[tag_name] = channels.get(tag_name, 0) + 1
        
        if channels:
            top_channel = max(channels, key=channels.get)
            report.append(f"\n📢 <b>Marketing Awareness:</b>")
            report.append(f"- Top kanal: <b>{top_channel}</b> ({channels[top_channel]} lid)")

        # 3. PRODUCTION & PM (Airtable)
        if self.airtable:
            projects = self.airtable.get_projects()
            overdue = self.airtable.get_overdue_projects()
            report.append(f"\n🏗 <b>Production & PM (Airtable):</b>")
            report.append(f"- Aktiv loyihalar: {len(projects)} ta")
            
            # 3 kunlik ishlab chiqarish qoidasi (SLA: 3 days)
            urgent_projects = []
            now_dt = datetime.datetime.now()
            
            for p in projects:
                fields = p.get('fields', {})
                created_str = fields.get('Created') or fields.get('Start Date') # Odatda loyiha yaratilgan sana
                stage = fields.get('Stage', '')
                
                if stage.lower() in ["done", "yakunlandi", "arxiv"]:
                    continue

                if created_str:
                    try:
                        # Created sana odatda ISO formatda "2026-03-29T..."
                        created_dt = datetime.datetime.fromisoformat(created_str.replace('Z', '+00:00'))
                        # Localize now to UTC for comparison if needed, or just naive if created is naive
                        if created_dt.tzinfo:
                            now_utc = datetime.datetime.now(datetime.timezone.utc)
                            diff = now_utc - created_dt
                        else:
                            diff = now_dt - created_dt
                            
                        # Agar 2 kundan oshgan bo'lsa (48h+) va hali bitmagan bo'lsa
                        if diff.days >= 2:
                            proj_name = fields.get('Project Name', 'Nomsiz')
                            urgent_projects.append(f"{proj_name} ({diff.days} kun o'tdi)")
                    except: continue

            if overdue:
                report.append(f"- Muddati o'tgan: {len(overdue)} ta ⚠️")
            
            if urgent_projects:
                report.append(f"- <b>SLA xavfi (3 kundan oshish arafasida):</b> {len(urgent_projects)} ta")
                report.append(f"  <i>(Iltimos, @Inomjon_JonBranding nazoratga oling)</i>")

        # 4. FINANCE SUMMARY (Airtable)
        if self.airtable:
            finance_records = self.airtable.get_finance_records()
            month_income = 0
            month_expense = 0
            current_month = datetime.datetime.now().strftime('%Y-%m')
            
            for rec in finance_records:
                f = rec.get("fields", {})
                date_str = f.get("Sana") or f.get("Date")
                if date_str and date_str.startswith(current_month):
                    amount = f.get("Summa") or 0
                    turi = f.get("Turi") or ""
                    if "Daromad" in turi or "Income" in turi:
                        month_income += amount
                    elif "Xarajat" in turi or "Expense" in turi:
                        month_expense += amount

            report.append(f"\n📈 <b>Oylik Moliya ({current_month}):</b>")
            report.append(f"- Jami tushum: {month_income:,.0f} so'm".replace(',', ' '))
            report.append(f"- Jami xarajat: {month_expense:,.0f} so'm".replace(',', ' '))
            net_profit = month_income - month_expense
            report.append(f"- **Sof Foyda: {net_profit:,.0f} so'm** {'🔥' if net_profit > 0 else '📉'}")

        report.append("\n💡 <i>Tizimli yondashuv — o'sish poydevori!</i>")
        return "\n".join(report)

    async def get_stagnant_leads_alert(self) -> str:
        """Kutilib qolgan lidlar uchun ogohlantirish."""
        # Oxirgi 24 soatda o'zgarmagan lidlarni topish
        leads = await self.crm.amocrm.get_leads_detailed(limit=50)
        now = datetime.datetime.now().timestamp()
        day_seconds = 24 * 3600
        
        stagnant = []
        for l in leads:
            # status_id 142, 143 bo'lsa tekshirmaymiz
            if l.get('status_id') in [self.WON_STATUS, self.LOST_STATUS]:
                continue
                
            updated_at = l.get('updated_at', 0)
            if (now - updated_at) > day_seconds:
                stagnant.append(l.get('name', f"ID:{l.get('id')}"))
        
        if stagnant:
            return f"🚨 <b>DIQQAT - Sales Stagnation!</b>\nQuyidagi lidlar 24 soatdan beri o'zgarmagan: {', '.join(stagnant[:5])}...\nIltimos, @Oydin_JonBranding va @tezmenejer harakat qiling!"
        return ""
