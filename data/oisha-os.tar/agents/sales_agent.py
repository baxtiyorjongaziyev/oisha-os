import logging
from agent_core import BaseAgent
from typing import Optional, Dict, Any
from google.genai import types

logger = logging.getLogger(__name__)

class SalesAgent(BaseAgent):
    """Mijozlar bilan sotuv va kelishuvlarni olib boruvchi agent."""
    
    def __init__(self, agent_id: str, system_prompt: str, api_keys: Dict[str, str], executor: Optional[Any] = None, db: Optional[Any] = None):
        super().__init__(agent_id, system_prompt, api_keys, executor, db)

    async def process_task(self, user_id: int, task_description: str, context: Optional[Dict[str, Any]] = None) -> str:
        """Sotuv bo'yicha muloqotni boshqarish."""
        self.update_history(user_id, "user", task_description)
        
        # Tarixni Gemini formatiga o'tkazish
        history = self.get_session_history(user_id)
        contents = []
        for turn in history:
            role = "user" if turn["role"] == "user" else "model"
            contents.append({"role": role, "parts": [{"text": turn["content"]}]})
            
        reply = await self.call_ai_with_fallback(contents, user_id)
        self.update_history(user_id, "assistant", reply)
        return reply
